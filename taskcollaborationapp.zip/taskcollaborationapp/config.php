<?php
$dsn = "mysql:host=localhost;dbname=OTS;charset=utf8mb4";
$db_username = "root"; 
$db_password = "";

try {
    $pdo = new PDO($dsn, $db_username, $db_password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$errors = [];
$fullName = $email = $password = $confirmPassword = $role = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Full Name Validation
    if (empty($_POST["fullName"]) || !preg_match("/^[a-zA-Z ]+$/", $_POST["fullName"])) {
        $errors['fullName'] = "Only alphabets and spaces are allowed.";
    } else {
        $fullName = trim($_POST["fullName"]);
    }

    // Email Validation
    if (empty($_POST["email"]) || !filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Enter a valid email address.";
    } else {
        $email = trim($_POST["email"]);
    }

    // Role Validation
    if (empty($_POST["role"])) {
        $errors['role'] = "Role is required.";
    } else {
        $role = trim($_POST["role"]);
    }

    // Password Validation
    if (empty($_POST["password"]) || !preg_match("/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/", $_POST["password"])) {
        $errors['password'] = "Password must have at least 8 characters, one uppercase, one lowercase, one number, and one special character.";
    } else {
        $password = $_POST["password"];
    }

    // Confirm Password Validation
    if (empty($_POST["confirmPassword"]) || $_POST["confirmPassword"] !== $_POST["password"]) {
        $errors['confirmPassword'] = "Passwords do not match.";
    }

    // Check if Email Already Exists
    $stmt = $pdo->prepare("SELECT id FROM registration WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        $errors['email'] = "This email is already registered.";
    }

    // If no errors, insert into database
    if (empty($errors)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $pdo->prepare("INSERT INTO registration (fullName, email, role, password) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$fullName, $email, $role, $hashedPassword])) {
            echo "<div class='alert alert-success'>Registration successful!</div>";
            $fullName = $email = $role = "";
        } else {
            echo "<div class='alert alert-danger'>Error: Unable to register.</div>";
        }
    }
}
?>
