<?php
session_start();
include('header.php');
include('sidebar.php');
include "../config.php";

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
$stmt = $pdo->query("SELECT tasks.*, registration.fullName FROM tasks 
                     JOIN registration ON tasks.user_id = registration.id 
                     ORDER BY tasks.deadline ASC");
$tasks = $stmt->fetchAll();
?>

<div class="wrapper">
    <!-- Main Content -->
    <div class="content">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container-fluid">
                <button class="btn btn-outline-light d-md-none" id="sidebarToggle">☰</button>
                <a class="navbar-brand mx-auto" href="#">Admin Dashboard</a>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <img src="profile.jpg" alt="Profile" class="rounded-circle" width="30" height="30">
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="#">Account</a></li>
                                <li><a class="dropdown-item" href="#">Settings</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container mt-5">
            <!-- <h2>Welcome to User Task Dashboard</h2> -->
            

            <div class="wrapper">
    <div class="content mt-5 pt-4">
        <div class="container">
            <h2>All User Tasks</h2>

            <table class="table table-bordered table-striped mt-auto">
                <thead class="table-dark">
                    <tr>
                        <th>User Name</th>
                        <th>Title</th>
                        <th>Deadline</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tasks as $task): ?>
                    <tr>
                        <td><?= htmlspecialchars($task['fullName']) ?></td>
                        <td><?= htmlspecialchars($task['title']) ?></td>
                        <td><?= htmlspecialchars($task['deadline']) ?></td>
                        <td><?= htmlspecialchars($task['priority']) ?></td>
                        <td><?= htmlspecialchars($task['status']) ?></td>
                        <td>
                            <a href="delete_task.php?id=<?= $task['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this task?');">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

        </div>
    </div>
</div>


        
        </div>
    </div>
    
        
        
</div>
<script>
    document.addEventListener("DOMContentLoaded", function() {
    const sidebar = document.getElementById("sidebar");
    const sidebarToggle = document.getElementById("sidebarToggle");

    sidebarToggle.addEventListener("click", function() {
        sidebar.classList.toggle("show");
    });
});

</script>
<?php include('footer.php'); ?>
