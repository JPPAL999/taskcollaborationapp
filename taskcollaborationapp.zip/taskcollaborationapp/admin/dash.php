<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include('header.php');
include('sidebar.php');
?>

<div class="wrapper">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <button class="btn btn-outline-light d-md-none" id="sidebarToggle">☰</button>
            <a class="navbar-brand mx-auto" href="#">Admin Dashboard</a>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <img src="#" alt="Profile" class="rounded-circle" width="30" height="30">
                        
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="#">Account</a></li>
                            <li><a class="dropdown-item" href="#">Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="content mt-5 pt-4">
        <div class="container">
            <!-- <h2>Welcome to Admin Dashboard</h2> -->
            <!-- Additional content goes here -->
        </div>
    </div>
</div>
<?php
// Fetch all users from the registration table
include "../config.php"; // ensure DB connection is available

$stmt = $pdo->query("SELECT id, fullName, email, role FROM registration ORDER BY id DESC");
$users = $stmt->fetchAll();
?>

<div class="container mt-4">
    <h4>Registered Users</h4>
    <table class="table table-bordered table-striped mt-3">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Role</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td><?= htmlspecialchars($user['id']) ?></td>
                <td><?= htmlspecialchars($user['fullName']) ?></td>
                <td><?= htmlspecialchars($user['email']) ?></td>
                <td><?= htmlspecialchars($user['role']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>


<!-- Sidebar Toggle Script -->
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const sidebar = document.getElementById("sidebar");
        const sidebarToggle = document.getElementById("sidebarToggle");

        if (sidebar && sidebarToggle) {
            sidebarToggle.addEventListener("click", function() {
                sidebar.classList.toggle("show");
            });
        }
    });
</script>

<?php include('footer.php'); ?>
