<?php
include('header.php');
include('sidebar.php');
include("../config.php")
?>

<div class="wrapper">
    <!-- Main Content -->
    <div class="content">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container-fluid">
                <button class="btn btn-outline-light d-md-none" id="sidebarToggle">☰</button>
                <a class="navbar-brand mx-auto" href="#">Project Dashboard</a>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <img src="profile.jpg" alt="Profile" class="rounded-circle" width="30" height="30">
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="#">Account</a></li>
                                <li><a class="dropdown-item" href="#">Settings</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container mt-5">
            <h2>All Students</h2>
            <?php
        include('fetchdata.php');
        ?>
            <!-- <p>Manage your projects efficiently.</p>    -->
        </div>
    </div>
</div>
<script>
    document.addEventListener("DOMContentLoaded", function() {
    const sidebar = document.getElementById("sidebar");
    const sidebarToggle = document.getElementById("sidebarToggle");

    sidebarToggle.addEventListener("click", function() {
        sidebar.classList.toggle("show");
    });
});

</script>
<?php include('footer.php'); ?>
