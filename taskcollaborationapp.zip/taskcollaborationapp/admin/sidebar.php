<!-- Sidebar -->
<nav id="sidebar" class="sidebar">
    <div class="sidebar-header text-center">
        <h4>sidebar</h4>
    </div>
    <ul class="list-unstyled">
        <li><a href="dash.php">Dashboard</a></li>
        
        <li><a href="task.php">Tasks</a></li>
        
    </ul>
</nav>
