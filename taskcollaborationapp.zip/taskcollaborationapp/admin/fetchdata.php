<?php
include("../config.php");
try {
    // Create PDO connection
    // $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    // $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepare and execute query
    $stmt = $pdo->prepare("SELECT id, fullName, email, countryCode, mobile, class, school FROM registration");
    $stmt->execute();

    // Fetch all records
    $registrations = $stmt->fetchAll(PDO::FETCH_ASSOC);

} 
catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>

<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover table-sm">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Country Code</th>
                <th>Mobile</th>
                <th>class</th>
                <th>School</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($registrations)): ?>
                <?php foreach ($registrations as $user): ?>
                    <tr id="row_<?php echo $user['id']; ?>">
                        <td><?php echo htmlspecialchars($user['id']); ?></td>
                        <td><?php echo htmlspecialchars($user['fullName']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['countryCode']); ?></td>
                        <td><?php echo htmlspecialchars($user['mobile']); ?></td>
                        <td><?php echo htmlspecialchars($user['class']); ?></td>
                        <td><?php echo htmlspecialchars($user['school']); ?></td>
                        <td>
                            <button class="btn btn-danger delete-btn" data-id="<?php echo $user['id']; ?>">
                                Delete
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" class="text-center">No records found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php
// include("../config.php");

if (isset($_POST['id'])) {
    $id = $_POST['id'];

    try {
        $stmt = $pdo->prepare("DELETE FROM registration WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo "success";
        } else {
            echo "error";
        }
    } catch (PDOException $e) {
        echo "error: " . $e->getMessage();
    }
}
?>
<script>
document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll(".delete-btn").forEach(button => {
        button.addEventListener("click", function() {
            let userId = this.getAttribute("data-id");
            let row = document.getElementById("row_" + userId);

            if (confirm("Are you sure you want to delete this record?")) {
                fetch("fetchdata.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    body: "id=" + userId
                })
                .then(response => response.text())
                .then(data => {
                    if (data.trim() === "success") {
                        row.remove(); // Remove row from table
                    } 
                    // else {
                    //     alert("Error deleting record.");
                    // }
                })
                .catch(error => console.error("Error:", error));
            }
        });
    });
});
</script>

