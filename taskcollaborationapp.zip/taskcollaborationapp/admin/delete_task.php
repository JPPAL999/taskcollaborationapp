<?php
session_start();
include('../config.php');
if (!isset($_SESSION['admin']) && !isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include('header.php');
include('sidebar.php');
if (isset($_GET['id'])) {
    $task_id = $_GET['id'];

    $stmt = $pdo->prepare("DELETE FROM tasks WHERE id = ?");
    if ($stmt->execute([$task_id])) {
        header("Location: " . $_SERVER['HTTP_REFERER']);
        exit();
    } else {
        echo "Failed to delete task.";
    }
}
?>




<?php include('footer.php'); ?>
