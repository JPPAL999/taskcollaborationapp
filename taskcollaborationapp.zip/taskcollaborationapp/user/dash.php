<?php
include('header.php');
include('sidebar.php');
include "../config.php";

// 🔐 Start session
session_start();

// ✅ Check if user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// 📧 Get logged-in user's email
$user_email = $_SESSION['email'];

// 🔍 Fetch only that user's data
$stmt = $pdo->prepare("SELECT id, fullName, email, password, role FROM registration WHERE email = ?");
$stmt->execute([$user_email]);
$users = $stmt->fetchAll();
?>

<div class="wrapper">
    <!-- Main Content -->
    <div class="content">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container-fluid">
                <button class="btn btn-outline-light d-md-none" id="sidebarToggle">☰</button>
                <a class="navbar-brand mx-auto" href="#">Task Collaboration App</a>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <img src="#" alt="Profile" class="rounded-circle" width="30" height="30"> 
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="#">Account</a></li>
                                <li><a class="dropdown-item" href="#">Settings</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container mt-5">
            <h2>Welcome to User Dashboard</h2>
            <p>Manage your projects efficiently.</p>

            <h4 class="mt-4">Your Details</h4>
            <table class="table table-striped mt-2">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Role</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['id']) ?></td>
                        <td><?= htmlspecialchars($user['fullName']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td><?= htmlspecialchars($user['password']) ?></td>
                        <td><?= htmlspecialchars($user['role']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const sidebar = document.getElementById("sidebar");
    const sidebarToggle = document.getElementById("sidebarToggle");
    sidebarToggle.addEventListener("click", function() {
        sidebar.classList.toggle("show");
    });
});
</script>

<?php include('./footer.php'); ?>
