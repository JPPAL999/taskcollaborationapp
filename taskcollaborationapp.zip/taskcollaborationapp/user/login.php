<?php
session_start();
include "../config.php"; // Ensure this file has a valid PDO connection

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format!";
    } else {
        // Prepare query using PDO
        $query = "SELECT * FROM registration WHERE email = :email";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(":email", $email, PDO::PARAM_STR);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // ✅ Correctly compare using password_verify
            if (password_verify($password, $user['password'])) {    
                // Store user data in session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['f_name'] = $user['fullName'] ?? 'Guest';
                $_SESSION['email'] = $user['email'];

                // Redirect to dashboard
                header("Location: dash.php");
                exit();
            } else {
                $error = "Invalid password!";
            }
        } else {
            $error = "Invalid email or password!";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    
    <div class="w-50 mx-auto">
        <h2>Login</h2>
        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">Email ID</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <small class="text-danger"><?php echo $error; ?></small>
            <button type="submit" name="login" class="btn btn-primary">Login</button>
        </form>

        <p class="mt-3">
            <a href="forgot_password.php">Forgot Password?</a>
        </p>
        <p>
            If you don't have an account, <a href="index.php">Register here</a>
        </p>
    </div>

</body>
</html>
