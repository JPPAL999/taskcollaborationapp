<?php
session_start();
$errors = [];
$mobile = "";
$otpSent = false;
$otpVerified = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['send_otp'])) {
        // Validate mobile number (10 digits only)
        if (empty($_POST['mobile']) || !preg_match("/^[0-9]{10}$/", $_POST['mobile'])) {
            $errors['mobile'] = "Enter a valid 10-digit mobile number.";
        } else {
            $mobile = $_POST['mobile'];
            $_SESSION['otp'] = rand(100000, 999999); // Generate 6-digit OTP
            $_SESSION['mobile'] = $mobile;
            $otpSent = true;
            // Here, you can integrate an SMS API to send the OTP
        }
    }
    
    if (isset($_POST['verify_otp'])) {
        if ($_POST['otp'] == $_SESSION['otp']) {
            $otpVerified = true;
        } else {
            $errors['otp'] = "Invalid OTP. Please try again.";
        }
    }

    if (isset($_POST['reset_password'])) {
        // Password validation
        if (empty($_POST['password']) || !preg_match("/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/", $_POST['password'])) {
            $errors['password'] = "Password must have at least 8 characters, one uppercase, one lowercase, one number, and one special character.";
        } elseif ($_POST['password'] !== $_POST['confirmPassword']) {
            $errors['confirmPassword'] = "Passwords do not match.";
        } else {
            // Here, you can update the password in the database
            session_destroy();
            header("Location: login.php");
            exit();
        }
    }
}
?>
<?php
include('header.php');
?>

<body class="container mt-5 ">
    <h2>Forgot Password</h2>
    
    <?php if (!$otpSent) : ?>
        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">Registered Mobile Number</label>
                <input type="text" name="mobile" class="form-control" required>
                <small class="text-danger"><?php echo $errors['mobile'] ?? ''; ?></small>
            </div>
            <button type="submit" name="send_otp" class="btn btn-primary">Send OTP</button>
        </form>
    <?php elseif (!$otpVerified) : ?>
        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">Enter OTP</label>
                <input type="text" name="otp" class="form-control" required>
                <small class="text-danger"><?php echo $errors['otp'] ?? ''; ?></small>
            </div>
            <button type="submit" name="verify_otp" class="btn btn-primary">Verify OTP</button>
        </form>
    <?php else : ?>
        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">New Password</label>
                <input type="password" name="password" class="form-control" required>
                <small class="text-danger"><?php echo $errors['password'] ?? ''; ?></small>
            </div>
            <div class="mb-3">
                <label class="form-label">Confirm Password</label>
                <input type="password" name="confirmPassword" class="form-control" required>
                <small class="text-danger"><?php echo $errors['confirmPassword'] ?? ''; ?></small>
            </div>
            <button type="submit" name="reset_password" class="btn btn-primary">Reset Password</button>
        </form>
    <?php endif; ?>

    <p class="mt-3"><a href="login.php">Back to Login</a></p>
    <?php
    include('footer.php');
    ?>