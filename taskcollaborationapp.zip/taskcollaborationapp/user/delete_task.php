<?php
session_start();
include "../config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$id = $_GET['id'] ?? 0;

$stmt = $pdo->prepare("DELETE FROM tasks WHERE id = ? AND user_id = ?");
if ($stmt->execute([$id, $user_id])) {
    header("Location: tasks.php");
    exit();
} else {
    echo "Failed to delete task.";
}
