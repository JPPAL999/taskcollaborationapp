<?php

session_start();
include "../config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$id = $_GET['id'] ?? 0;

$stmt = $pdo->prepare("SELECT * FROM tasks WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user_id]);
$task = $stmt->fetch();

if (!$task) {
    echo "Task not found.";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $deadline = $_POST['deadline'];
    $priority = $_POST['priority'];
    $status = $_POST['status'];

    $stmt = $pdo->prepare("UPDATE tasks SET title = ?, deadline = ?, priority = ?, status = ? WHERE id = ? AND user_id = ?");
    if ($stmt->execute([$title, $deadline, $priority, $status, $id, $user_id])) {
        header("Location: tasks.php");
        exit();
    } else {
        echo "Failed to update task.";
    }
}
?>

<form method="POST">
    <input type="text" name="title" value="<?= htmlspecialchars($task['title']) ?>" class="form-control mb-2" required>
    <input type="date" name="deadline" value="<?= $task['deadline'] ?>" class="form-control mb-2" required>
    <select name="priority" class="form-control mb-2">
        <option value="Low" <?= $task['priority'] === 'Low' ? 'selected' : '' ?>>Low</option>
        <option value="Medium" <?= $task['priority'] === 'Medium' ? 'selected' : '' ?>>Medium</option>
        <option value="High" <?= $task['priority'] === 'High' ? 'selected' : '' ?>>High</option>
    </select>
    <select name="status" class="form-control mb-2">
        <option value="Pending" <?= $task['status'] === 'Pending' ? 'selected' : '' ?>>Pending</option>
        <option value="In Progress" <?= $task['status'] === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
        <option value="Completed" <?= $task['status'] === 'Completed' ? 'selected' : '' ?>>Completed</option>
    </select>
    <button type="submit" class="btn btn-success">Update Task</button>
</form>
