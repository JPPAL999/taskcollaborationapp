<?php
include('header.php');
include('sidebar.php');
?>

<div class="wrapper">
    <!-- Main Content -->
    <div class="content">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container-fluid">
                <button class="btn btn-outline-light d-md-none" id="sidebarToggle">☰</button>
                <a class="navbar-brand mx-auto" href="#">Task Collaboration App</a>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <img src="profile.jpg" alt="Profile" class="rounded-circle" width="30" height="30">
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="#">Account</a></li>
                                <li><a class="dropdown-item" href="#">Settings</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container mt-5">
            <h2>Welcome to User Task Dashboard</h2>
            <?php
session_start();
include "../config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$errors = [];
$title = $deadline = $priority = $status = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $title = trim($_POST['title']);
    $deadline = $_POST['deadline'];
    $priority = $_POST['priority'];
    $status = $_POST['status'];

    // Basic validation
    if (empty($title)) $errors['title'] = "Title is required.";
    if (empty($deadline)) $errors['deadline'] = "Deadline is required.";

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO tasks (user_id, title, deadline, priority, status) VALUES (?, ?, ?, ?, ?)");
        if ($stmt->execute([$user_id, $title, $deadline, $priority, $status])) {
            echo "<div class='alert alert-success'>Task added successfully!</div>";
        } else {
            echo "<div class='alert alert-danger'>Failed to add task.</div>";
        }
    }
}
?>

<!-- HTML Form -->
<form method="POST">
    <input type="text" name="title" placeholder="Task Title" class="form-control mb-2">
    <input type="date" name="deadline" class="form-control mb-2">
    <select name="priority" class="form-control mb-2">
        <option value="Low">Low</option>
        <option value="Medium" selected>Medium</option>
        <option value="High">High</option>
    </select>
    <select name="status" class="form-control mb-2">
        <option value="Pending" selected>Pending</option>
        <option value="In Progress">In Progress</option>
        <option value="Completed">Completed</option>
    </select>
    <button type="submit" class="btn btn-primary">Add Task</button>
</form>
<?php
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM tasks WHERE user_id = ?");
$stmt->execute([$user_id]);
$tasks = $stmt->fetchAll();
?>

<table class="table">
    <thead>
        <tr>
            <th>Title</th>
            <th>Deadline</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($tasks as $task): ?>
        <tr>
            <td><?= htmlspecialchars($task['title']) ?></td>
            <td><?= htmlspecialchars($task['deadline']) ?></td>
            <td><?= htmlspecialchars($task['priority']) ?></td>
            <td><?= htmlspecialchars($task['status']) ?></td>
            <td>
                <a href="edit_task.php?id=<?= $task['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                <a href="delete_task.php?id=<?= $task['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this task?');">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>


        
        </div>
    </div>
    
        
        
</div>
<script>
    document.addEventListener("DOMContentLoaded", function() {
    const sidebar = document.getElementById("sidebar");
    const sidebarToggle = document.getElementById("sidebarToggle");

    sidebarToggle.addEventListener("click", function() {
        sidebar.classList.toggle("show");
    });
});

</script>
<?php include('footer.php'); ?>
