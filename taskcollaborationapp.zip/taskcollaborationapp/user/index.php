<?php
include "../config.php"; // PDO connection

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Validation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
<div class="w-50 mx-auto">
    <h2>Registration Form</h2>
    <form method="POST" action="">
    <div class="mb-3">
    <label class="form-label">Full Name</label>
    <input type="text" name="fullName" class="form-control" value="<?php echo htmlspecialchars($fullName); ?>">
    <small class="text-danger"><?php echo $errors['fullName'] ?? ''; ?></small>
</div>
<div class="mb-3">
    <label class="form-label">Email</label>
    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>">
    <small class="text-danger"><?php echo $errors['email'] ?? ''; ?></small>
</div>
<div class="mb-3">
    <label class="form-label">Password</label>
    <input type="password" name="password" class="form-control">
    <small class="text-danger"><?php echo $errors['password'] ?? ''; ?></small>
</div>
<div class="mb-3">
    <label class="form-label">Confirm Password</label>
    <input type="password" name="confirmPassword" class="form-control">
    <small class="text-danger"><?php echo $errors['confirmPassword'] ?? ''; ?></small>
</div>
<div class="mb-3">
    <label class="form-label">Role</label>
    <input type="text" name="role" class="form-control" value="<?php echo htmlspecialchars($role); ?>">
    <small class="text-danger"><?php echo $errors['role'] ?? ''; ?></small>
</div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
    <p class="mt-3">If you already have an account <a href="login.php">Login</a>.</p>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
